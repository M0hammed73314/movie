class NavigateModel {
  num? id;

  NavigateModel(this.id);
}
