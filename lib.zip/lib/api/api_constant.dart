class ApiConstant {
  static String BaseUrl = "api.themoviedb.org";
  static String popularService = "/3/movie/popular";
  static String popularService2 = "/3/movie/upcoming";
  static String popularService3 = "/3/movie/top_rated";
  static String popularService4 = "/3/search/movie";
  static String genresName = "/3/genre/movie/list";
  static String movieList = "/3/discover/movie";
  static String movieDetails = "/3/movie";
  static String popularServiceMovieDetails = '/3/movie/';
  static const String APIKEY = 'c4c3d1e82f8dee40ffdf440f479d9373';
}
